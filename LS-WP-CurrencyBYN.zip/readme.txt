=== LS WP Currency BYN ===
Contributors: lightningsoft
Tags: currency, byn
Requires at least: 5.4
Tested up to: 5.4
Stable tag: 1.0.0
Requires PHP: 5.6
License: GPLv2 or later

Shows currency exchange rates for Belarus

== Description ==

Shows currency exchange rates for Belarus

== Installation ==

Upload the LS WP Currency BYN plugin to your blog and activate it.

== Changelog ==

= 1.0.0 =
* 
Release Date - 15 December 2020 
*
